<?php
include 'conexao.php';

$sql = "SELECT * FROM orcamentos ORDER BY data_cotacao DESC";
$result = $conn->query($sql);

// Calcular totais e economia
$sqlTotais = "
    SELECT 
        SUM(valor_inicial) as total_inicial,
        SUM(valor_negociado) as total_negociado,
        SUM(valor_inicial - valor_negociado) as total_economia,
        COUNT(*) as total_orcamentos,
        AVG(valor_inicial - valor_negociado) as media_economia
    FROM orcamentos
";
$resultTotais = $conn->query($sqlTotais);
$totais = $resultTotais->fetch_assoc();

$totalInicial = $totais['total_inicial'] ?? 0;
$totalNegociado = $totais['total_negociado'] ?? 0;
$totalEconomia = $totais['total_economia'] ?? 0;
$totalOrcamentos = $totais['total_orcamentos'] ?? 0;
$mediaEconomia = $totais['media_economia'] ?? 0;

// Calcular percentual de economia geral
$percentualEconomia = $totalInicial > 0 ? (($totalEconomia / $totalInicial) * 100) : 0;
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Lista de Orçamentos</title>
    <style>
        body { font-family: Helvetica; background: #f9f9f9; padding: 20px; }
        
        /* Cards de resumo */
        .resumo-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .card-resumo {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .card-resumo h3 {
            margin: 0 0 10px 0;
            font-size: 14px;
            color: #666;
            text-transform: uppercase;
        }
        
        .card-resumo .valor {
            font-size: 24px;
            font-weight: bold;
            margin: 0;
        }
        
        .valor.economia { color: #4caf50; }
        .valor.inicial { color: #2196f3; }
        .valor.negociado { color: #ff9800; }
        .valor.percentual { color: #9c27b0; }
        
        /* Tabela */
        table { 
            width: 100%; 
            border-collapse: collapse; 
            background: white; 
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        
        th, td { 
            padding: 12px; 
            border-bottom: 1px solid #ddd; 
            text-align: left; 
        }
        
        th { 
            background-color: #f0f0f0; 
            font-weight: bold;
        }
        
        /* Coluna de economia */
        .economia-positiva { 
            color: #4caf50; 
            font-weight: bold; 
        }
        
        .economia-negativa { 
            color: #f44336; 
            font-weight: bold; 
        }
        
        .economia-zero { 
            color: #666; 
        }
        
        h2 { margin-bottom: 20px; }
        a { text-decoration: none; color: #007BFF; }
        a:hover { text-decoration: underline; }
        
        .btn-voltar { 
            display: inline-block; 
            margin-top: 20px; 
            background: #333; 
            color: #fff; 
            padding: 10px 15px; 
            border-radius: 6px; 
        }
        
        .btn-voltar:hover { background: #555; }
        
        .status-aprovado { 
            background: #e8f5e8; 
            color: #4caf50; 
            padding: 4px 8px; 
            border-radius: 4px; 
            font-size: 12px;
        }
        
        .status-pendente { 
            background: #fff3cd; 
            color: #856404; 
            padding: 4px 8px; 
            border-radius: 4px; 
            font-size: 12px;
        }
        
        .status-rejeitado { 
            background: #f8d7da; 
            color: #721c24; 
            padding: 4px 8px; 
            border-radius: 4px; 
            font-size: 12px;
        }
    </style>
</head>
<body>


<style>
.top-menu {
    background-color: #2c3e50;
    overflow: hidden;
    margin: -20px -20px 20px -20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.top-menu a {
    float: left;
    display: block;
    color: white;
    text-align: center;
    padding: 14px 20px;
    text-decoration: none;
    font-size: 16px;
    transition: background-color 0.3s;
}

.top-menu a:hover {
    background-color: #34495e;
    color: white;
}

.top-menu a.active {
    background-color: #3498db;
    color: white;
}

/* Responsivo */
@media screen and (max-width: 600px) {
    .top-menu a {
        float: none;
        display: block;
        text-align: left;
        padding: 12px 16px;
    }
}
</style>

<div class="top-menu">
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="cadastrar.php">➕ Cadastrar</a>
</div>

<h2>📋 Lista de Orçamentos</h2>

<!-- Cards de Resumo -->
<div class="resumo-container">
    <div class="card-resumo">
        <h3>💰 Total Economizado</h3>
        <p class="valor economia">R$ <?= number_format($totalEconomia, 2, ',', '.') ?></p>
    </div>
    
    <div class="card-resumo">
        <h3>📊 Total de Orçamentos</h3>
        <p class="valor"><?= number_format($totalOrcamentos, 0, ',', '.') ?></p>
    </div>
    
    <div class="card-resumo">
        <h3>📈 Economia Média</h3>
        <p class="valor economia">R$ <?= number_format($mediaEconomia, 2, ',', '.') ?></p>
    </div>
    
    <div class="card-resumo">
        <h3>📉 % de Economia</h3>
        <p class="valor percentual"><?= number_format($percentualEconomia, 1, ',', '.') ?>%</p>
    </div>
    
    <div class="card-resumo">
        <h3>💵 Valor Total Inicial</h3>
        <p class="valor inicial">R$ <?= number_format($totalInicial, 2, ',', '.') ?></p>
    </div>
    
    <div class="card-resumo">
        <h3>💸 Valor Total Negociado</h3>
        <p class="valor negociado">R$ <?= number_format($totalNegociado, 2, ',', '.') ?></p>
    </div>
</div>

<table>
    <thead>
        <tr>
            <th>Fornecedor</th>
            <th>Categoria</th>
            <th>Produto</th>
            <th>Descrição</th>
            <th>Valor Inicial</th>
            <th>Valor Negociado</th>
            <th>💰 Economia</th>
            <th>📊 % Economia</th>
            <th>Status</th>
            <th>Data</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        // Reset do resultado para percorrer novamente
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()): 
            $economia = $row['valor_inicial'] - $row['valor_negociado'];
            $percentualItem = $row['valor_inicial'] > 0 ? (($economia / $row['valor_inicial']) * 100) : 0;
            
            // Definir classe CSS baseada na economia
            $economiaClass = '';
            if ($economia > 0) {
                $economiaClass = 'economia-positiva';
            } elseif ($economia < 0) {
                $economiaClass = 'economia-negativa';
            } else {
                $economiaClass = 'economia-zero';
            }
            
            // Definir classe do status
            $statusClass = '';
            switch(strtolower($row['status'])) {
                case 'aprovado':
                    $statusClass = 'status-aprovado';
                    break;
                case 'pendente':
                    $statusClass = 'status-pendente';
                    break;
                case 'rejeitado':
                    $statusClass = 'status-rejeitado';
                    break;
            }
        ?>
            <tr>
                <td><?= htmlspecialchars($row['nome_fornecedor']) ?></td>
                <td><?= htmlspecialchars($row['categoria']) ?></td>
                <td><?= htmlspecialchars($row['produto']) ?></td>
                <td><?= htmlspecialchars($row['descricao']) ?></td>
                <td>R$ <?= number_format($row['valor_inicial'], 2, ',', '.') ?></td>
                <td>R$ <?= number_format($row['valor_negociado'], 2, ',', '.') ?></td>
                <td class="<?= $economiaClass ?>">
                    R$ <?= number_format($economia, 2, ',', '.') ?>
                </td>
                <td class="<?= $economiaClass ?>">
                    <?= number_format($percentualItem, 1, ',', '.') ?>%
                </td>
                <td>
                    <span class="<?= $statusClass ?>">
                        <?= htmlspecialchars($row['status']) ?>
                    </span>
                </td>
                <td><?= date("d/m/Y", strtotime($row['data_cotacao'])) ?></td>
                <td>
                    <a href="editar.php?id=<?= $row['id'] ?>">Editar</a> |
                    <a href="excluir.php?id=<?= $row['id'] ?>" onclick="return confirm('Tem certeza que deseja excluir este orçamento?')">Excluir</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<a class="btn-voltar" href="cadastrar.php">🔙 Voltar ao Início</a>

</body>
</html>

<?php
$conn->close();
?>
