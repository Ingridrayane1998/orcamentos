<?php
include 'conexao.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    die("ID inválido.");
}

$stmt = $conn->prepare("SELECT * FROM orcamentos WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$dados = $result->fetch_assoc();
$stmt->close();

if (!$dados) {
    die("Orçamento não encontrado.");
}
?>

<form action="atualizar.php" method="post">
    <input type="hidden" name="id" value="<?= htmlspecialchars($id) ?>">

    <label for="nome_fornecedor">Nome:</label>
    <input type="text" id="nome_fornecedor" name="nome_fornecedor" value="<?= htmlspecialchars($dados['nome_fornecedor']) ?>"><br>

     <label for="categoria">Categoria:</label>
    <input type="text" id="categoria" name="categoria" value="<?= htmlspecialchars($dados['categoria']) ?>"><br>

     <label for="produto">produto:</label>
    <input type="text" id="produto" name="produto" value="<?= htmlspecialchars($dados['produto']) ?>"><br>

     <label for="descricao">Descrição:</label>
    <input type="text" id="descricao" name="descricao" value="<?= htmlspecialchars($dados['descricao']) ?>"><br>

    <label for="valor_inicial">Valor Inicial:</label>
    <input type="number" step="0.01" id="valor_inicial" name="valor_inicial" value="<?= htmlspecialchars($dados['valor_inicial']) ?>"><br>

    <label for="valor_negociado">Valor Negociado:</label>
    <input type="number" step="0.01" id="valor_negociado" name="valor_negociado" value="<?= htmlspecialchars($dados['valor_negociado']) ?>"><br>

    <label for="status">Status:</label>
    <select id="status" name="status">
        <option value="Pendente" <?= $dados['status'] == 'Pendente' ? 'selected' : '' ?>>Pendente</option>
        <option value="Aprovado" <?= $dados['status'] == 'Aprovado' ? 'selected' : '' ?>>Aprovado</option>
    </select><br>

    <label for="data_cotacao">Data:</label>
    <input type="date" id="data_cotacao" name="data_cotacao" value="<?= htmlspecialchars($dados['data_cotacao']) ?>"><br>

    <input type="submit" value="Atualizar">
</form>
