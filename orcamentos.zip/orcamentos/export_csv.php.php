<?php
include 'conexao.php';

// Recebe os mesmos filtros do dashboard
$categoriaFiltro = $_GET['categoria'] ?? '';
$mesFiltro = $_GET['mes'] ?? '';
$anoFiltro = $_GET['ano'] ?? '';
$dataInicio = $_GET['data_inicio'] ?? '';
$dataFim = $_GET['data_fim'] ?? '';

// Montar cláusula WHERE conforme filtros (mesmo código do dashboard)
$where = [];
$params = [];

if ($categoriaFiltro !== '') {
    $where[] = "categoria = ?";
    $params[] = $categoriaFiltro;
}

if ($mesFiltro !== '' && $anoFiltro !== '') {
    $where[] = "MONTH(data_cotacao) = ? AND YEAR(data_cotacao) = ?";
    $params[] = $mesFiltro;
    $params[] = $anoFiltro;
} elseif ($dataInicio !== '' && $dataFim !== '') {
    $where[] = "data_cotacao BETWEEN ? AND ?";
    $params[] = $dataInicio;
    $params[] = $dataFim;
}

$whereSql = "";
if (count($where) > 0) {
    $whereSql = " WHERE " . implode(' AND ', $where);
}

// Função para preparar e executar query com params
function queryWithParams($conn, $sql, $params) {
    $stmt = $conn->prepare($sql);
    if ($params) {
        $types = str_repeat('s', count($params));
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    return $stmt->get_result();
}

// Buscar todos os dados para o CSV
$sqlCSV = "SELECT 
    nome_fornecedor,
    categoria,
    produto,
    descricao,
    valor_inicial,
    valor_negociado,
    (valor_inicial - valor_negociado) as economia,
    ROUND(((valor_inicial - valor_negociado) / valor_inicial) * 100, 2) as percentual_economia,
    status,
    data_cotacao
FROM orcamentos" . $whereSql . " ORDER BY data_cotacao DESC";

$result = queryWithParams($conn, $sqlCSV, $params);

// Configurar headers para download
$filename = "relatorio_orcamentos_" . date('Y-m-d_H-i-s') . ".csv";
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');

// Criar o arquivo CSV
$output = fopen('php://output', 'w');

// BOM para UTF-8 (para Excel reconhecer acentos)
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

// Cabeçalhos do CSV
$headers = [
    'Fornecedor',
    'Categoria', 
    'Produto',
    'Descrição',
    'Valor Inicial (R$)',
    'Valor Negociado (R$)',
    'Economia (R$)',
    'Percentual Economia (%)',
    'Status',
    'Data Cotação'
];

fputcsv($output, $headers, ';');

// Dados
while ($row = $result->fetch_assoc()) {
    $linha = [
        $row['nome_fornecedor'],
        $row['categoria'],
        $row['produto'],
        $row['descricao'],
        number_format($row['valor_inicial'], 2, ',', '.'),
        number_format($row['valor_negociado'], 2, ',', '.'),
        number_format($row['economia'], 2, ',', '.'),
        number_format($row['percentual_economia'], 2, ',', '.') . '%',
        $row['status'],
        date('d/m/Y', strtotime($row['data_cotacao']))
    ];
    
    fputcsv($output, $linha, ';');
}

// Adicionar linha de totais
$sqlTotais = "
    SELECT 
        SUM(valor_inicial) as total_inicial,
        SUM(valor_negociado) as total_negociado,
        SUM(valor_inicial - valor_negociado) as total_economia,
        COUNT(*) as total_orcamentos
    FROM orcamentos
    $whereSql
";
$resultTotais = queryWithParams($conn, $sqlTotais, $params);
$totais = $resultTotais->fetch_assoc();

// Linha em branco
fputcsv($output, [''], ';');

// Linha de totais
$linhaTotais = [
    'TOTAIS',
    '',
    '',
    '',
    number_format($totais['total_inicial'], 2, ',', '.'),
    number_format($totais['total_negociado'], 2, ',', '.'),
    number_format($totais['total_economia'], 2, ',', '.'),
    $totais['total_inicial'] > 0 ? number_format((($totais['total_economia'] / $totais['total_inicial']) * 100), 2, ',', '.') . '%' : '0%',
    $totais['total_orcamentos'] . ' orçamentos',
    ''
];

fputcsv($output, $linhaTotais, ';');

fclose($output);
$conn->close();
?>
