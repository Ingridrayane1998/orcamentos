<?php
include 'conexao.php';

$id = $_POST['id'];
$nome = $_POST['nome_fornecedor'];
$categoria = $_POST['categoria'];
$produto = $_POST['produto'];
$descricao = $_POST['descricao'];
$valor_inicial = $_POST['valor_inicial'];
$valor_negociado = $_POST['valor_negociado'];
$status = $_POST['status'];
$data = $_POST['data_cotacao'];

$sql = "UPDATE orcamentos SET 
        nome_fornecedor='$nome',
        categoria='$categoria',
        produto='$produto',
        descricao='$descricao',
        valor_inicial='$valor_inicial',
        valor_negociado='$valor_negociado',
        status='$status',
        data_cotacao='$data'
        WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    echo "Orçamento atualizado com sucesso! <a href='listar.php'>Voltar</a>";
} else {
    echo "Erro: " . $conn->error;
}
$conn->close();
?>
