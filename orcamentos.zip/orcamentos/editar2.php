<?php
session_start();
include 'conexao.php';

// Verifica se o usuário está logado (opcional, mas recomendado)
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

// Recebe o ID do orçamento para editar
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    die('ID inválido.');
}

// Busca o orçamento no banco
$stmt = $conn->prepare("SELECT * FROM orcamentos WHERE id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();
$orcamento = $result->fetch_assoc();
$stmt->close();

if (!$orcamento) {
    die('Orçamento não encontrado.');
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <title>Editar Orçamento #<?= htmlspecialchars($orcamento['id']) ?></title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f9f9f9; }
        form { background: white; padding: 20px; border-radius: 8px; max-width: 600px; margin: auto; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        label { display: block; margin-top: 15px; font-weight: bold; }
        input[type="text"], input[type="number"], select, textarea {
            width: 100%; padding: 8px; margin-top: 5px; border: 1px solid #ccc; border-radius: 4px;
        }
        button {
            margin-top: 20px; padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer;
        }
        button:hover { background: #0056b3; }
        a { display: inline-block; margin-top: 20px; text-decoration: none; color: #555; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>

<h2>Editar Orçamento #<?= htmlspecialchars($orcamento['id']) ?></h2>

<form method="POST" action="processa_editar.php">
    <input type="hidden" name="id" value="<?= htmlspecialchars($orcamento['id']) ?>">

    <label for="nome_fornecedor">Fornecedor</label>
    <input type="text" id="nome_fornecedor" name="nome_fornecedor" required
           value="<?= htmlspecialchars($orcamento['nome_fornecedor']) ?>">

    <label for="categoria">Categoria</label>
    <input type="text" id="categoria" name="categoria" required
           value="<?= htmlspecialchars($orcamento['categoria']) ?>">

    <label for="produto">Produto</label>
    <input type="text" id="produto" name="produto" required
           value="<?= htmlspecialchars($orcamento['produto']) ?>">

    <label for="descricao">Descrição</label>
    <textarea id="descricao" name="descricao" rows="3" required><?= htmlspecialchars($orcamento['descricao']) ?></textarea>

    <label for="valor_inicial">Valor Inicial</label>
    <input type="number" step="0.01" id="valor_inicial" name="valor_inicial" required
           value="<?= htmlspecialchars($orcamento['valor_inicial']) ?>">

    <label for="valor_negociado">Valor Negociado</label>
    <input type="number" step="0.01" id="valor_negociado" name="valor_negociado" required
           value="<?= htmlspecialchars($orcamento['valor_negociado']) ?>">

    <label for="status">Status</label>
    <select id="status" name="status" required>
        <?php
        $statusOptions = ['Pendente', 'Aprovado', 'Rejeitado'];
        foreach ($statusOptions as $status) {
            $selected = (strcasecmp($orcamento['status'], $status) === 0) ? 'selected' : '';
            echo "<option value=\"$status\" $selected>$status</option>";
        }
        ?>
    </select>

    <button type="submit">Salvar Alterações</button>
</form>

<a href="listar.php">← Voltar para Lista de Orçamentos</a>

</body>
</html>
