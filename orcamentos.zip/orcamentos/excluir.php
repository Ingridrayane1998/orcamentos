<?php
include 'conexao.php';
$id = $_GET['id'];
$conn->query("DELETE FROM orcamentos WHERE id=$id");
header("Location: listar.php");
?>
