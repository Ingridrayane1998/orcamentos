<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Cadastrar Orçamento</title>
    <style>
        body {
            font-family: Arial, sans-serif; /* Fonte mais moderna */
            background-color: #f4f4f4; /* Cor de fundo mais suave */
            padding: 20px;
        }

        .top-menu {
            background-color: #2c3e50; /* Cor primária mais vibrante */
            overflow: hidden;
            padding: 10px 0;
        }
        .top-menu a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 12px 20px;
            text-decoration: none;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .top-menu a:hover, .top-menu a.active {
            background-color: #2c3e50; /* Efeito de hover mais distinto */
        }

        h2 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            max-width: 600px;
            margin: auto;
        }

        label {
            font-weight: bold;
            display: block;
            margin: 10px 0 5px;
        }

        input[type="text"], input[type="number"], input[type="date"], select, textarea {
            width: 100%;
            padding: 8px;
            margin: 5px 0 20px;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box; /* Ajusta a largura do input para não ultrapassar o container */
        }

        input[type="submit"] {
            width: 100%;
            background-color: #4CAF50;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        a {
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>


<div class="top-menu">
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="listar.php">📋 Listar</a>
</div>


<h2>Cadastro de Orçamento</h2>
<form action="processa_cadastro.php" method="post">
    <label for="produto">Produto:</label>
    <input type="text" id="produto" name="produto" required>

    <label for="descricao">Descrição:</label>
    <textarea id="descricao" name="descricao" rows="4" cols="50" required></textarea>

    <label for="nome_fornecedor">Nome do Fornecedor:</label>
    <input type="text" id="nome_fornecedor" name="nome_fornecedor" required>

    <label for="categoria">Categoria:</label>
    <input type="text" id="categoria" name="categoria" required>

    <label for="valor_inicial">Valor Inicial:</label>
    <input type="number" id="valor_inicial" name="valor_inicial" step="0.01" required>

    <label for="valor_negociado">Valor Negociado:</label>
    <input type="number" id="valor_negociado" name="valor_negociado" step="0.01" required>

    <label for="status">Status:</label>
    <select id="status" name="status">
        <option value="Pendente">Pendente</option>
        <option value="Aprovado">Aprovado</option>
    </select>

    <label for="data_cotacao">Data da Cotação:</label>
    <input type="date" id="data_cotacao" name="data_cotacao" required>

    <input type="submit" value="Salvar Orçamento">
</form>
<a href="listar.php">Ver Orçamentos</a>

</body>
</html>
