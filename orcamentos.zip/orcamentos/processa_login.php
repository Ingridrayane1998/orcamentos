<?php
session_start();

// Configuração do banco de dados
$servername = "localhost";
$username = "seu_usuario";
$password = "sua_senha";
$dbname = "if0_39200862_negociacao";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    if ($_POST) {
        $email = $_POST['email'];
        $senha = $_POST['senha'];
        
        // Buscar usuário no banco
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ? AND ativo = 1");
        $stmt->execute([$email]);
        $usuario = $stmt->fetch();
        
        if ($usuario && password_verify($senha, $usuario['senha'])) {
            // Login bem-sucedido
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['usuario_nome'] = $usuario['nome'];
            $_SESSION['usuario_email'] = $usuario['email'];
            $_SESSION['usuario_nivel'] = $usuario['nivel_acesso'];
            
            header("Location: dashboard.php");
            exit();
        } else {
            // Login falhou
            $_SESSION['erro_login'] = "Email ou senha incorretos!";
            header("Location: login.php");
            exit();
        }
    }
    
} catch(PDOException $e) {
    $_SESSION['erro_login'] = "Erro de conexão: " . $e->getMessage();
    header("Location: login.php");
    exit();
}
?>
