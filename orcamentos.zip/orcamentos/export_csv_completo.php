<?php
include 'conexao.php';

// Recebe os filtros do formulário
$categoriaFiltro = $_GET['categoria'] ?? '';
$mesFiltro = $_GET['mes'] ?? '';
$anoFiltro = $_GET['ano'] ?? '';
$dataInicio = $_GET['data_inicio'] ?? '';
$dataFim = $_GET['data_fim'] ?? '';

// Montar cláusula WHERE conforme filtros
$where = [];
$params = [];

if ($categoriaFiltro !== '') {
    $where[] = "categoria = ?";
    $params[] = $categoriaFiltro;
}

if ($mesFiltro !== '' && $anoFiltro !== '') {
    $where[] = "MONTH(data_cotacao) = ? AND YEAR(data_cotacao) = ?";
    $params[] = $mesFiltro;
    $params[] = $anoFiltro;
} elseif ($dataInicio !== '' && $dataFim !== '') {
    $where[] = "data_cotacao BETWEEN ? AND ?";
    $params[] = $dataInicio;
    $params[] = $dataFim;
}

$whereSql = "";
if (count($where) > 0) {
    $whereSql = " WHERE " . implode(' AND ', $where);
}

// Função para preparar e executar query com params
function queryWithParams($conn, $sql, $params) {
    $stmt = $conn->prepare($sql);
    if ($params) {
        $types = str_repeat('s', count($params));
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    return $stmt->get_result();
}

try {
    // Configurar headers para download
    $filename = "relatorio_completo_orcamentos_" . date('Y-m-d_H-i-s') . ".csv";
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Pragma: no-cache');
    header('Expires: 0');

    // Criar o arquivo CSV
    $output = fopen('php://output', 'w');

    // BOM para UTF-8 (para Excel reconhecer acentos)
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

    // ========================================
    // SEÇÃO 1: CABEÇALHO DO RELATÓRIO
    // ========================================
    fputcsv($output, ['RELATÓRIO COMPLETO DE ORÇAMENTOS'], ';');
    fputcsv($output, ['Gerado em: ' . date('d/m/Y H:i:s')], ';');
    
    // Mostrar filtros aplicados
    $filtrosAplicados = [];
    if ($categoriaFiltro) $filtrosAplicados[] = "Categoria: $categoriaFiltro";
    if ($mesFiltro && $anoFiltro) $filtrosAplicados[] = "Período: $mesFiltro/$anoFiltro";
    if ($dataInicio && $dataFim) $filtrosAplicados[] = "Período: $dataInicio a $dataFim";
    
    if (!empty($filtrosAplicados)) {
        fputcsv($output, ['Filtros aplicados: ' . implode(' | ', $filtrosAplicados)], ';');
    } else {
        fputcsv($output, ['Filtros aplicados: Nenhum (todos os dados)'], ';');
    }
    
    fputcsv($output, [''], ';'); // Linha em branco

    // ========================================
    // SEÇÃO 2: RESUMO GERAL
    // ========================================
    fputcsv($output, ['=== RESUMO GERAL ==='], ';');
    fputcsv($output, ['Métrica', 'Valor'], ';');

    // Calcular totais
    $sqlTotais = "
        SELECT 
            SUM(valor_inicial) as total_inicial,
            SUM(valor_negociado) as total_negociado,
            SUM(valor_inicial - valor_negociado) as total_economia,
            COUNT(*) as total_orcamentos,
            AVG(valor_inicial - valor_negociado) as media_economia,
            COUNT(CASE WHEN status = 'Aprovado' THEN 1 END) as total_aprovados,
            COUNT(CASE WHEN status = 'Pendente' THEN 1 END) as total_pendentes,
            COUNT(CASE WHEN status = 'Rejeitado' THEN 1 END) as total_rejeitados
        FROM orcamentos
        $whereSql
    ";
    $resultTotais = queryWithParams($conn, $sqlTotais, $params);
    $totais = $resultTotais->fetch_assoc();

    $totalInicial = $totais['total_inicial'] ?? 0;
    $totalNegociado = $totais['total_negociado'] ?? 0;
    $totalEconomia = $totais['total_economia'] ?? 0;
    $totalOrcamentos = $totais['total_orcamentos'] ?? 0;
    $mediaEconomia = $totais['media_economia'] ?? 0;
    $percentualEconomia = $totalInicial > 0 ? (($totalEconomia / $totalInicial) * 100) : 0;

    fputcsv($output, ['Total de Orçamentos', number_format($totalOrcamentos, 0, ',', '.')], ';');
    fputcsv($output, ['Orçamentos Aprovados', number_format($totais['total_aprovados'], 0, ',', '.')], ';');
    fputcsv($output, ['Orçamentos Pendentes', number_format($totais['total_pendentes'], 0, ',', '.')], ';');
    fputcsv($output, ['Orçamentos Rejeitados', number_format($totais['total_rejeitados'], 0, ',', '.')], ';');
    fputcsv($output, ['Valor Total Inicial', 'R$ ' . number_format($totalInicial, 2, ',', '.')], ';');
    fputcsv($output, ['Valor Total Negociado', 'R$ ' . number_format($totalNegociado, 2, ',', '.')], ';');
    fputcsv($output, ['Total Economizado', 'R$ ' . number_format($totalEconomia, 2, ',', '.')], ';');
    fputcsv($output, ['Percentual de Economia', number_format($percentualEconomia, 2, ',', '.') . '%'], ';');
    fputcsv($output, ['Economia Média por Orçamento', 'R$ ' . number_format($mediaEconomia, 2, ',', '.')], ';');

    fputcsv($output, [''], ';'); // Linha em branco

    // ========================================
    // SEÇÃO 3: ECONOMIA POR CATEGORIA
    // ========================================
    fputcsv($output, ['=== ECONOMIA POR CATEGORIA ==='], ';');
    fputcsv($output, ['Categoria', 'Qtd Orçamentos', 'Valor Inicial (R$)', 'Valor Negociado (R$)', 'Economia (R$)', 'Percentual Economia (%)'], ';');

    $sqlCategorias = "
        SELECT 
            categoria,
            COUNT(*) as quantidade,
            SUM(valor_inicial) as total_inicial,
            SUM(valor_negociado) as total_negociado,
            SUM(valor_inicial - valor_negociado) AS economia
        FROM orcamentos 
        $whereSql 
        GROUP BY categoria
        ORDER BY economia DESC
    ";
    $resultCategorias = queryWithParams($conn, $sqlCategorias, $params);

    while ($row = $resultCategorias->fetch_assoc()) {
        $percentual = $row['total_inicial'] > 0 ? (($row['economia'] / $row['total_inicial']) * 100) : 0;
        fputcsv($output, [
            $row['categoria'],
            number_format($row['quantidade'], 0, ',', '.'),
            'R$ ' . number_format($row['total_inicial'], 2, ',', '.'),
            'R$ ' . number_format($row['total_negociado'], 2, ',', '.'),
            'R$ ' . number_format($row['economia'], 2, ',', '.'),
            number_format($percentual, 2, ',', '.') . '%'
        ], ';');
    }

    fputcsv($output, [''], ';'); // Linha em branco

    // ========================================
    // SEÇÃO 4: EVOLUÇÃO MENSAL
    // ========================================
    fputcsv($output, ['=== EVOLUÇÃO MENSAL ==='], ';');
    fputcsv($output, ['Mês/Ano', 'Qtd Orçamentos', 'Valor Inicial (R$)', 'Valor Negociado (R$)', 'Economia (R$)', 'Percentual Economia (%)'], ';');

    $sqlEvolucao = "
        SELECT 
            DATE_FORMAT(data_cotacao, '%m/%Y') AS mes_ano,
            COUNT(*) as quantidade,
            SUM(valor_inicial) AS total_inicial,
            SUM(valor_negociado) AS total_negociado,
            SUM(valor_inicial - valor_negociado) AS economia
        FROM orcamentos
        $whereSql
        GROUP BY DATE_FORMAT(data_cotacao, '%Y-%m')
        ORDER BY DATE_FORMAT(data_cotacao, '%Y-%m') ASC
    ";
    $resultEvolucao = queryWithParams($conn, $sqlEvolucao, $params);

    while ($row = $resultEvolucao->fetch_assoc()) {
        $percentual = $row['total_inicial'] > 0 ? (($row['economia'] / $row['total_inicial']) * 100) : 0;
        fputcsv($output, [
            $row['mes_ano'],
            number_format($row['quantidade'], 0, ',', '.'),
            'R$ ' . number_format($row['total_inicial'], 2, ',', '.'),
            'R$ ' . number_format($row['total_negociado'], 2, ',', '.'),
            'R$ ' . number_format($row['economia'], 2, ',', '.'),
            number_format($percentual, 2, ',', '.') . '%'
        ], ';');
    }

    fputcsv($output, [''], ';'); // Linha em branco

    // ========================================
    // SEÇÃO 5: STATUS DOS ORÇAMENTOS
    // ========================================
    fputcsv($output, ['=== DISTRIBUIÇÃO POR STATUS ==='], ';');
    fputcsv($output, ['Status', 'Quantidade', 'Percentual (%)'], ';');

    $sqlStatus = "SELECT status, COUNT(*) as total FROM orcamentos" . $whereSql . " GROUP BY status ORDER BY total DESC";
    $resultStatus = queryWithParams($conn, $sqlStatus, $params);

    while ($row = $resultStatus->fetch_assoc()) {
        $percentual = $totalOrcamentos > 0 ? (($row['total'] / $totalOrcamentos) * 100) : 0;
        fputcsv($output, [
            $row['status'],
            number_format($row['total'], 0, ',', '.'),
            number_format($percentual, 1, ',', '.') . '%'
        ], ';');
    }

    fputcsv($output, [''], ';'); // Linha em branco

    // ========================================
    // SEÇÃO 6: TOP 10 MAIORES ECONOMIAS
    // ========================================
    fputcsv($output, ['=== TOP 10 MAIORES ECONOMIAS ==='], ';');
    fputcsv($output, ['Posição', 'Fornecedor', 'Categoria', 'Produto', 'Economia (R$)', 'Percentual Economia (%)'], ';');

    $sqlTop10 = "
        SELECT 
            nome_fornecedor,
            categoria,
            produto,
            valor_inicial,
            valor_negociado,
            (valor_inicial - valor_negociado) as economia
        FROM orcamentos 
        $whereSql 
        ORDER BY economia DESC 
        LIMIT 10
    ";
    $resultTop10 = queryWithParams($conn, $sqlTop10, $params);

    $posicao = 1;
    while ($row = $resultTop10->fetch_assoc()) {
        $percentual = $row['valor_inicial'] > 0 ? (($row['economia'] / $row['valor_inicial']) * 100) : 0;
        fputcsv($output, [
            $posicao . 'º',
            $row['nome_fornecedor'],
            $row['categoria'],
            $row['produto'],
            'R$ ' . number_format($row['economia'], 2, ',', '.'),
            number_format($percentual, 2, ',', '.') . '%'
        ], ';');
        $posicao++;
    }

    fputcsv($output, [''], ';'); // Linha em branco

    // ========================================
    // SEÇÃO 7: DETALHAMENTO COMPLETO
    // ========================================
    fputcsv($output, ['=== DETALHAMENTO COMPLETO DOS ORÇAMENTOS ==='], ';');
    fputcsv($output, [
        'ID',
        'Fornecedor',
        'Categoria', 
        'Produto',
        'Descrição',
        'Valor Inicial (R$)',
        'Valor Negociado (R$)',
        'Economia (R$)',
        'Percentual Economia (%)',
        'Status',
        'Data Cotação',
        'Usuário'
    ], ';');

    // Lista completa dos orçamentos
    $sqlCompleto = "SELECT * FROM orcamentos" . $whereSql . " ORDER BY data_cotacao DESC";
    $resultCompleto = queryWithParams($conn, $sqlCompleto, $params);

    while ($row = $resultCompleto->fetch_assoc()) {
        $economia = $row['valor_inicial'] - $row['valor_negociado'];
        $percentualItem = $row['valor_inicial'] > 0 ? (($economia / $row['valor_inicial']) * 100) : 0;
        
        fputcsv($output, [
            $row['id'],
            $row['nome_fornecedor'],
            $row['categoria'],
            $row['produto'],
            $row['descricao'],
            'R$ ' . number_format($row['valor_inicial'], 2, ',', '.'),
            'R$ ' . number_format($row['valor_negociado'], 2, ',', '.'),
            'R$ ' . number_format($economia, 2, ',', '.'),
            number_format($percentualItem, 2, ',', '.') . '%',
            $row['status'],
            date('d/m/Y', strtotime($row['data_cotacao'])),
            $row['nome'] ?? 'N/A'
        ], ';');
    }

    // ========================================
    // SEÇÃO 8: RODAPÉ
    // ========================================
    fputcsv($output, [''], ';'); // Linha em branco
    fputcsv($output, ['=== FIM DO RELATÓRIO ==='], ';');
    fputcsv($output, ['Relatório gerado automaticamente pelo Sistema de Orçamentos'], ';');
    fputcsv($output, [''], ';'); // Linha em branco
    fputcsv($output, ['=== FIM DO RELATÓRIO ==='], ';');
    fputcsv($output, ['Relatório gerado automaticamente pelo Sistema de Orçamentos'], ';');
    fputcsv($output, ['Data/Hora: ' . date('d/m/Y H:i:s')], ';');

    fclose($output);
    
} catch (Exception $e) {
    // Em caso de erro, mostrar mensagem
    echo "Erro ao gerar relatório: " . $e->getMessage();
    echo "<br><a href='dashboard.php'>Voltar ao Dashboard</a>";
}

$conn->close();
?>
