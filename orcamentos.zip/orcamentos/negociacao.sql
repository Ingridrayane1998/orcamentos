
USE if0_39200862_negociacao;


CREATE TABLE orcamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_fornecedor VARCHAR(100),
    valor_inicial DECIMAL(10,2),
    valor_negociado DECIMAL(10,2),
    status ENUM('Aprovado', 'Pendente'),
    data_cotacao DATE
);

ALTER TABLE orcamentos ADD categoria VARCHAR(100) AFTER nome_fornecedor;


SELECT * from orcamentos;

ALTER TABLE orcamentos 
ADD COLUMN produto VARCHAR(150) AFTER categoria,
ADD COLUMN descricao TEXT AFTER produto;



