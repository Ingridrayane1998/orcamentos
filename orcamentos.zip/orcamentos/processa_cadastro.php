<?php
include 'conexao.php';

$nome = $_POST['nome_fornecedor'];
$categoria = $_POST['categoria'];
$produto = $_POST['produto'];
$descricao = $_POST['descricao'];
$valor_inicial = $_POST['valor_inicial'];
$valor_negociado = $_POST['valor_negociado'];
$status = $_POST['status'];
$data = $_POST['data_cotacao'];

$sql = "INSERT INTO orcamentos (nome_fornecedor, categoria, produto, descricao, valor_inicial, valor_negociado, status, data_cotacao)
        VALUES ('$nome', '$categoria', '$produto', '$descricao', '$valor_inicial', '$valor_negociado', '$status', '$data')";

if ($conn->query($sql) === TRUE) {
    echo "Orçamento cadastrado com sucesso! <a href='listar.php'>Ver todos</a>";
} else {
    echo "Erro: " . $conn->error;
}
$conn->close();
?>
