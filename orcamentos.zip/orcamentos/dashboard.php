<?php
include 'conexao.php';

// Recebe os filtros do formulário
$categoriaFiltro = $_GET['categoria'] ?? '';
$mesFiltro = $_GET['mes'] ?? '';
$anoFiltro = $_GET['ano'] ?? '';
$dataInicio = $_GET['data_inicio'] ?? '';
$dataFim = $_GET['data_fim'] ?? '';

// Montar cláusula WHERE conforme filtros
$where = [];
$params = [];

if ($categoriaFiltro !== '') {
    $where[] = "categoria = ?";
    $params[] = $categoriaFiltro;
}

if ($mesFiltro !== '' && $anoFiltro !== '') {
    $where[] = "MONTH(data_cotacao) = ? AND YEAR(data_cotacao) = ?";
    $params[] = $mesFiltro;
    $params[] = $anoFiltro;
} elseif ($dataInicio !== '' && $dataFim !== '') {
    $where[] = "data_cotacao BETWEEN ? AND ?";
    $params[] = $dataInicio;
    $params[] = $dataFim;
}

$whereSql = "";
if (count($where) > 0) {
    $whereSql = " WHERE " . implode(' AND ', $where);
}

// Função para preparar e executar query com params
function queryWithParams($conn, $sql, $params) {
    $stmt = $conn->prepare($sql);
    if ($params) {
        $types = str_repeat('s', count($params));
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    return $stmt->get_result();
}

// 1. Calcular totais e economia geral (com filtros)
$sqlTotais = "
    SELECT 
        SUM(valor_inicial) as total_inicial,
        SUM(valor_negociado) as total_negociado,
        SUM(valor_inicial - valor_negociado) as total_economia,
        COUNT(*) as total_orcamentos,
        AVG(valor_inicial - valor_negociado) as media_economia
    FROM orcamentos
    $whereSql
";
$resultTotais = queryWithParams($conn, $sqlTotais, $params);
$totais = $resultTotais->fetch_assoc();

$totalInicial = $totais['total_inicial'] ?? 0;
$totalNegociado = $totais['total_negociado'] ?? 0;
$totalEconomia = $totais['total_economia'] ?? 0;
$totalOrcamentos = $totais['total_orcamentos'] ?? 0;
$mediaEconomia = $totais['media_economia'] ?? 0;
$percentualEconomia = $totalInicial > 0 ? (($totalEconomia / $totalInicial) * 100) : 0;

// 2. Lista de orçamentos aprovados (considera filtros)
$sqlLista = "SELECT * FROM orcamentos" . ($whereSql ? $whereSql . " AND status = 'Aprovado'" : " WHERE status = 'Aprovado'");
$resultLista = queryWithParams($conn, $sqlLista, $params);

// 3. Gráfico barras: economia por categoria
$sqlBarras = "
    SELECT 
        categoria, 
        SUM(valor_inicial - valor_negociado) AS economia,
        SUM(valor_inicial) as total_inicial,
        SUM(valor_negociado) as total_negociado
    FROM orcamentos 
    $whereSql 
    GROUP BY categoria
";
$resultBarras = queryWithParams($conn, $sqlBarras, $params);
$categorias = [];
$economiasCategoria = [];
while ($row = $resultBarras->fetch_assoc()) {
    $categorias[] = $row['categoria'];
    $economiasCategoria[] = (float)$row['economia'];
}

// 4. Gráfico pizza: quantidade por status
$sqlPizza = "SELECT status, COUNT(*) as total FROM orcamentos" . $whereSql . " GROUP BY status";
$resultPizza = queryWithParams($conn, $sqlPizza, $params);
$labelsStatus = [];
$dadosStatus = [];
while ($row = $resultPizza->fetch_assoc()) {
    $labelsStatus[] = $row['status'];
    $dadosStatus[] = $row['total'];
}

// 5. Gráfico linha: evolução da economia mensal
$sqlEvolucao = "
    SELECT 
        DATE_FORMAT(data_cotacao, '%Y-%m') AS mes_ano,
        SUM(valor_inicial - valor_negociado) AS economia,
        SUM(valor_inicial) AS total_inicial,
        SUM(valor_negociado) AS total_negociado
    FROM orcamentos
    $whereSql
    GROUP BY mes_ano
    ORDER BY mes_ano ASC
";
$resultEvolucao = queryWithParams($conn, $sqlEvolucao, $params);
$meses = [];
$economias = [];
$totaisIniciais = [];
$totaisNegociados = [];
while ($row = $resultEvolucao->fetch_assoc()) {
    $meses[] = $row['mes_ano'];
    $economias[] = (float)$row['economia'];
    $totaisIniciais[] = (float)$row['total_inicial'];
    $totaisNegociados[] = (float)$row['total_negociado'];
}

// 6. Gráfico de percentual de economia por categoria
$sqlPercentual = "
    SELECT 
        categoria,
        SUM(valor_inicial) as total_inicial,
        SUM(valor_negociado) as total_negociado,
        ROUND(((SUM(valor_inicial) - SUM(valor_negociado)) / SUM(valor_inicial)) * 100, 2) as percentual_economia
    FROM orcamentos
    $whereSql
    GROUP BY categoria
    HAVING SUM(valor_inicial) > 0
";
$resultPercentual = queryWithParams($conn, $sqlPercentual, $params);
$categoriasPerc = [];
$percentuais = [];
while ($row = $resultPercentual->fetch_assoc()) {
    $categoriasPerc[] = $row['categoria'];
    $percentuais[] = (float)$row['percentual_economia'];
}

// Para popular filtro de categorias
$categoriaOptions = $conn->query("SELECT DISTINCT categoria FROM orcamentos ORDER BY categoria ASC");
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Dashboard de Orçamentos</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
    body { 
        font-family: Arial; 
        padding: 20px; 
        background: #f7f7f7; 
        margin: 0;
    }
    
    /* Cards de resumo */
    .cards-container {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin: 20px 0 30px 0;
    }
    
    .card {
        background: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        text-align: center;
        border-left: 4px solid #4caf50;
    }
    
    .card.inicial { border-left-color: #2196f3; }
    .card.negociado { border-left-color: #ff9800; }
    .card.economia { border-left-color: #4caf50; }
    .card.percentual { border-left-color: #9c27b0; }
    .card.media { border-left-color: #607d8b; }
    .card.total { border-left-color: #795548; }
    
    .card h4 {
        margin: 0 0 10px 0;
        color: #666;
        font-size: 14px;
        text-transform: uppercase;
        font-weight: normal;
    }
    
    .card .valor {
        font-size: 28px;
        font-weight: bold;
        margin: 0;
        color: #333;
    }
    
    .card.economia .valor { color: #4caf50; }
    .card.inicial .valor { color: #2196f3; }
    .card.negociado .valor { color: #ff9800; }
    .card.percentual .valor { color: #9c27b0; }
    
    /* Filtros */
    .filtros { 
        background: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        margin-bottom: 20px; 
    }
    
    .filtros label {
        margin-right: 15px;
        font-weight: bold;
    }
    
    .filtros select, .filtros input {
        padding: 8px;
        border: 1px solid #ddd;
        border-radius: 4px;
        margin-left: 5px;
    }
    
    .filtros button {
        background: #4caf50;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        margin-left: 10px;
    }
    
    .filtros button:hover {
        background: #45a049;
    }
    
    .filtros a {
        background: #f44336;
        color: white;
        padding: 10px 20px;
        text-decoration: none;
        border-radius: 4px;
        margin-left: 10px;
    }
    
    /* Gráficos */
    .graficos-container {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .grafico {
        background: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    
    .grafico h3 {
        margin: 0 0 15px 0;
        color: #333;
        text-align: center;
    }
    
    /* Tabela */
    table { 
        border-collapse: collapse; 
        width: 100%; 
        background: #fff;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    
    th, td { 
        border: 1px solid #ddd; 
        padding: 12px; 
        text-align: left; 
    }
    
    th { 
        background: #f8f9fa; 
        color: #333;
        font-weight: bold;
    }
    
    h2, h3 { color: #333; }
    
    .economia-positiva { 
        color: #4caf50; 
        font-weight: bold; 
    }
    
    .economia-negativa { 
        color: #f44336; 
        font-weight: bold; 
    }
    
    .economia-zero { 
        color: #666; 
    }
    
    a { 
        color: #007BFF; 
        text-decoration: none; 
    }
    
    a:hover { 
        text-decoration: underline; 
    }
</style>
</head>
<body>

<style>
.top-menu {
    background-color: #2c3e50;
    overflow: hidden;
    margin: -20px -20px 20px -20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.top-menu a {
    float: left;
    display: block;
    color: white;
    text-align: center;
    padding: 14px 20px;
    text-decoration: none;
    font-size: 16px;
    transition: background-color 0.3s;
}

.top-menu a:hover {
    background-color: #34495e;
    color: white;
}

.top-menu a.active {
    background-color: #3498db;
    color: white;
}

/* Responsivo */
@media screen and (max-width: 600px) {
    .top-menu a {
        float: none;
        display: block;
        text-align: left;
        padding: 12px 16px;
    }
}
</style>

<div class="top-menu">
    <a href="cadastrar.php">➕ Cadastrar</a>
    <a href="listar.php">📋 Gestão de Negociações</a>
</div>
<h2>📊 Dashboard de Orçamentos</h2>

<!-- Cards de Resumo -->
<div class="cards-container">
    <div class="card economia">
        <h4>💰 Total Economizado</h4>
        <div class="valor">R$ <?= number_format($totalEconomia, 2, ',', '.') ?></div>
    </div>
    
    <div class="card percentual">
        <h4>📊 % de Economia</h4>
        <div class="valor"><?= number_format($percentualEconomia, 1, ',', '.') ?>%</div>
    </div>
    
    <div class="card total">
        <h4>📋 Total de Orçamentos</h4>
        <div class="valor"><?= number_format($totalOrcamentos, 0, ',', '.') ?></div>
    </div>
    
    <div class="card media">
        <h4>📈 Economia Média</h4>
        <div class="valor">R$ <?= number_format($mediaEconomia, 2, ',', '.') ?></div>
    </div>
    
    <div class="card inicial">
        <h4>💵 Valor Total Inicial</h4>
        <div class="valor">R$ <?= number_format($totalInicial, 2, ',', '.') ?></div>
    </div>
    
    <div class="card negociado">
        <h4>💸 Valor Total Negociado</h4>
        <div class="valor">R$ <?= number_format($totalNegociado, 2, ',', '.') ?></div>
    </div>
</div>

<div class="filtros">
    <form method="GET" action="">
        <label>Categoria:
            <select name="categoria">
                <option value="">Todas</option>
                <?php while ($cat = $categoriaOptions->fetch_assoc()): ?>
                    <option value="<?= htmlspecialchars($cat['categoria']) ?>" <?= ($cat['categoria'] == $categoriaFiltro ? 'selected' : '') ?>>
                        <?= htmlspecialchars($cat['categoria']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </label>

        <label>Mês:
            <select name="mes">
                <option value="">--</option>
                <?php for ($m=1; $m<=12; $m++): ?>
                    <option value="<?= $m ?>" <?= ($mesFiltro == $m ? 'selected' : '') ?>>
                        <?= str_pad($m,2,'0',STR_PAD_LEFT) ?>
                    </option>
                <?php endfor; ?>
            </select>
        </label>

        <label>Ano:
            <select name="ano">
                <option value="">--</option>
                <?php
                $anoAtual = date('Y');
                for ($a=$anoAtual-5; $a<=$anoAtual; $a++): ?>
                    <option value="<?= $a ?>" <?= ($anoFiltro == $a ? 'selected' : '') ?>>
                        <?= $a ?>
                    </option>
                <?php endfor; ?>
            </select>
        </label>

        <br><br>

        <label>Data Início:
            <input type="date" name="data_inicio" value="<?= htmlspecialchars($dataInicio) ?>">
        </label>

        <label>Data Fim:
            <input type="date" name="data_fim" value="<?= htmlspecialchars($dataFim) ?>">
        </label>

        <button type="submit">Filtrar</button>
        <a href="dashboard.php">Limpar</a>
    </form>
</div

</div>

<div class="graficos-container">
    <div class="grafico">
        <h3>💰 Economia por Categoria</h3>
        <canvas id="graficoBarras"></canvas>
    </div>

    <div class="grafico">
        <h3>📈 Status dos Orçamentos</h3>
        <canvas id="graficoPizza"></canvas>
    </div>

    <div class="grafico">
        <h3>📉 Evolução da Economia Mensal</h3>
        <canvas id="graficoLinha"></canvas>
    </div>

    <div class="grafico">
        <h3>📊 % de Economia por Categoria</h3>
        <canvas id="graficoPercentual"></canvas>
    </div>

    <div class="grafico">
        <h3>💹 Comparativo Inicial vs Negociado</h3>
        <canvas id="graficoComparativo"></canvas>
    </div>

    <div class="grafico">
        <h3>🎯 Distribuição de Economia</h3>
        <canvas id="graficoDoughnut"></canvas>
    </div>
</div>

<h3>📋 Lista de Orçamentos Aprovados</h3>
<table>
    <tr>
        <th>Fornecedor</th>
        <th>Categoria</th>
        <th>Produto</th>
        <th>Descrição</th>
        <th>Valor Inicial</th>
        <th>Valor Negociado</th>
        <th>💰 Economia</th>
        <th>📊 % Economia</th>
        <th>Status</th>
        <th>Data</th>
        <th>Ações</th>
    </tr>
    <?php 
    // Reset do resultado para percorrer novamente
    $resultLista = queryWithParams($conn, $sqlLista, $params);
    while ($row = $resultLista->fetch_assoc()) : 
        $economia = $row['valor_inicial'] - $row['valor_negociado'];
        $percentualItem = $row['valor_inicial'] > 0 ? (($economia / $row['valor_inicial']) * 100) : 0;
        
        // Definir classe CSS baseada na economia
        $economiaClass = '';
        if ($economia > 0) {
            $economiaClass = 'economia-positiva';
        } elseif ($economia < 0) {
            $economiaClass = 'economia-negativa';
        } else {
            $economiaClass = 'economia-zero';
        }
    ?>
        <tr>
            <td><?= htmlspecialchars($row['nome_fornecedor']) ?></td>
            <td><?= htmlspecialchars($row['categoria']) ?></td>
            <td><?= htmlspecialchars($row['produto']) ?></td>
            <td><?= htmlspecialchars($row['descricao']) ?></td>
            <td>R$ <?= number_format($row['valor_inicial'], 2, ',', '.') ?></td>
            <td>R$ <?= number_format($row['valor_negociado'], 2, ',', '.') ?></td>
            <td class="<?= $economiaClass ?>">
                R$ <?= number_format($economia, 2, ',', '.') ?>
            </td>
            <td class="<?= $economiaClass ?>">
                <?= number_format($percentualItem, 1, ',', '.') ?>%
            </td>
            <td><?= htmlspecialchars($row['status']) ?></td>
            <td><?= date('d/m/Y', strtotime($row['data_cotacao'])) ?></td>
            <td>
                <a href="editar.php?id=<?= $row['id'] ?>">Editar</a> | 
                <a href="excluir.php?id=<?= $row['id'] ?>" onclick="return confirm('Tem certeza?')">Excluir</a>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Configurações globais do Chart.js
    Chart.defaults.plugins.legend.position = 'bottom';
    Chart.defaults.plugins.legend.labels.padding = 20;

    // 1. Gráfico de barras - Economia por Categoria
    new Chart(document.getElementById('graficoBarras'), {
        type: 'bar',
        data: {
            labels: <?= json_encode($categorias) ?>,
            datasets: [{
                label: 'Economia por Categoria (R$)',
                data: <?= json_encode($economiasCategoria) ?>,
                backgroundColor: '#4caf50',
                borderColor: '#388e3c',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Economia: R$ ' + context.parsed.y.toLocaleString('pt-BR', {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2
                            });
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return 'R$ ' + value.toLocaleString('pt-BR');
                        }
                    }
                }
            }
        }
    });

    // 2. Gráfico de pizza - Status dos Orçamentos
    new Chart(document.getElementById('graficoPizza'), {
        type: 'pie',
        data: {
            labels: <?= json_encode($labelsStatus) ?>,
            datasets: [{
                label: 'Quantidade por Status',
                data: <?= json_encode($dadosStatus) ?>,
                backgroundColor: [
                    '#4caf50',  // Aprovado
                    '#ff9800',  // Pendente
                    '#f44336',  // Rejeitado
                    '#2196f3',  // Outros
                    '#9c27b0'
                ],
                borderWidth: 2,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((context.parsed / total) * 100).toFixed(1);
                            return context.label + ': ' + context.parsed + ' (' + percentage + '%)';
                        }
                    }
                }
            }
        }
    });

    // 3. Gráfico de linha - Evolução da Economia Mensal
    new Chart(document.getElementById('graficoLinha'), {
        type: 'line',
        data: {
            labels: <?= json_encode($meses) ?>,
            datasets: [
                {
                    label: 'Economia Mensal (R$)',
                    data: <?= json_encode($economias) ?>,
                    fill: true,
                    backgroundColor: 'rgba(76, 175, 80, 0.1)',
                    borderColor: '#4caf50',
                    borderWidth: 3,
                    tension: 0.4,
                    pointBackgroundColor: '#4caf50',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 6
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Economia: R$ ' + context.parsed.y.toLocaleString('pt-BR', {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2
                            });
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return 'R$ ' + value.toLocaleString('pt-BR');
                        }
                    }
                }
            }
        }
    });

    // 4. Gráfico de barras horizontais - Percentual de Economia por Categoria
    new Chart(document.getElementById('graficoPercentual'), {
        type: 'bar',
        data: {
            labels: <?= json_encode($categoriasPerc) ?>,
            datasets: [{
                label: 'Percentual de Economia (%)',
                data: <?= json_encode($percentuais) ?>,
                backgroundColor: '#9c27b0',
                borderColor: '#7b1fa2',
                borderWidth: 1
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Economia: ' + context.parsed.x.toFixed(1) + '%';
                        }
                    }
                }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            }
        }
    });

    // 5. Gráfico comparativo - Inicial vs Negociado por mês
    new Chart(document.getElementById('graficoComparativo'), {
        type: 'bar',
        data: {
            labels: <?= json_encode($meses) ?>,
            datasets: [
                {
                    label: 'Valor Inicial (R$)',
                    data: <?= json_encode($totaisIniciais) ?>,
                    backgroundColor: '#2196f3',
                    borderColor: '#1976d2',
                    borderWidth: 1
                },
                {
                    label: 'Valor Negociado (R$)',
                    data: <?= json_encode($totaisNegociados) ?>,
                    backgroundColor: '#ff9800',
                    borderColor: '#f57c00',
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': R$ ' + context.parsed.y.toLocaleString('pt-BR', {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2
                            });
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return 'R$ ' + value.toLocaleString('pt-BR');
                        }
                    }
                }
            }
        }
    });

    // 6. Gráfico Doughnut - Distribuição da Economia
    const economiaData = <?= json_encode($economiasCategoria) ?>;
    const economiaLabels = <?= json_encode($categorias) ?>;
    
    new Chart(document.getElementById('graficoDoughnut'), {
        type: 'doughnut',
        data: {
            labels: economiaLabels,
            datasets: [{
                label: 'Distribuição da Economia',
                data: economiaData,
                backgroundColor: [
                    '#4caf50',
                    '#2196f3',
                    '#ff9800',
                    '#f44336',
                    '#9c27b0',
                    '#607d8b',
                    '#795548',
                    '#e91e63'
                ],
                borderWidth: 3,
                borderColor: '#fff',
                hoverBorderWidth: 4
            }]
        },
        options: {
            responsive: true,
            cutout: '60%',
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((context.parsed / total) * 100).toFixed(1);
                            return context.label + ': R$ ' + context.parsed.toLocaleString('pt-BR', {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2
                            }) + ' (' + percentage + '%)';
                        }
                    }
                }
            }
        }
    });
</script>

</body>
</html>

<?php
$conn->close();
?>

